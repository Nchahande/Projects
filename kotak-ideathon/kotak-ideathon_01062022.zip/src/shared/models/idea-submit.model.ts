export interface IdeaSubmit {
}
