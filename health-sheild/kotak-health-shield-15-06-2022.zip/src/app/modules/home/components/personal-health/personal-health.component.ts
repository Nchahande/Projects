import { Component, OnInit, Input, ChangeDetectorRef, AfterViewChecked, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
declare let $: any;

@Component({
  selector: 'app-personal-health',
  templateUrl: './personal-health.component.html',
  styleUrls: ['./personal-health.component.css']
})
export class PersonalHealthComponent implements OnInit {
  formSubmitted = false;
  livoShieldForm: FormGroup;
  accidentCover: FormGroup;
  livoShieldFormFilled = false;
  accidentCoverFilled = false;

  constructor(private router: Router, private fb: FormBuilder, private modalService: NgbModal,) { }

  ngOnInit(): void {
    this.livoShieldForm = this.fb.group({
      livoHospitalized: ['', Validators.required],
      bloodIssue: ['', Validators.required],
      mri: ['', Validators.required],
      surgery: ['', Validators.required]
    });

    this.accidentCover = this.fb.group({
      hazardousActivities: ['', Validators.required],
      adventurousSports: ['', Validators.required],
      disability: ['', Validators.required]
    });
  }

  livoShield() {
    if (this.livoShieldForm.controls['livoHospitalized'].value
      && this.livoShieldForm.controls['bloodIssue'].value
      && this.livoShieldForm.controls['mri'].value
      && this.livoShieldForm.controls['surgery'].value
    ) {
      this.livoShieldFormFilled = true;
    } else {
      this.livoShieldFormFilled = false;
    }
  }

  accidentCoverQAndA() {
    if (this.accidentCover.controls['hazardousActivities'].value
      && this.accidentCover.controls['adventurousSports'].value
      && this.accidentCover.controls['disability'].value
    ) {
      this.accidentCoverFilled = true;
    } else {
      this.accidentCoverFilled = false;
    }
  }

  navigate() {
    this.formSubmitted = true;
    if (this.livoShieldForm.valid && this.accidentCover.valid) {
      this.router.navigate(['other-details']);
    } else {
      setTimeout(() => {
        this.moveToError();
      }, 500);
    }
  }
  back() {
    this.router.navigate(['policy-health']);
  }
  moveToError() {
    var elt = $(".errorMsg");
    if (elt.length) {
      $('html, body').animate({
        scrollTop: (elt.first().offset().top) - 100
      }, 500);
    }
  }
  gotoFailed() {
    this.router.navigate(['failed']);
  }
}
