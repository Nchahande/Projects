import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-abort',
  templateUrl: './abort.component.html',
  styleUrls: ['./abort.component.css']
})
export class AbortComponent implements OnInit {

  constructor(private location: Location) { }

  ngOnInit(): void {
  }
  navigateBack() {
    this.location.back();
  }
}
