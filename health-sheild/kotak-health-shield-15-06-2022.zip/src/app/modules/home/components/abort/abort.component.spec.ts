import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AbortComponent } from './abort.component';

describe('AbortComponent', () => {
  let component: AbortComponent;
  let fixture: ComponentFixture<AbortComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AbortComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AbortComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
