import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { DateValidator } from '../../../../shared/date-validator.validator';
import { Router } from '@angular/router';
@Component({
  selector: 'app-resume-page',
  templateUrl: './resume-page.component.html',
  styleUrls: ['./resume-page.component.css']
})
export class ResumePageComponent implements OnInit {
  resumeForm: FormGroup;
  formSubmitted = false;
  showMinor = false;
  minDate = { year: 1920, month: 1, day: 1 };
  age = 0;
  constructor(private fb: FormBuilder, private router: Router,private location: Location) { }

  ngOnInit(): void {
    this.resumeForm = this.fb.group({
      quoteId: ['', [Validators.required]],
      birthdate: ['', Validators.compose([Validators.required, DateValidator.dateValidator])],
    });
  }
  ageCalc() {
    const birthdate = this.resumeForm.get('birthdate').value;
    const DOB = new Date(birthdate.year, birthdate.month - 1, birthdate.day);
    const timeDiff = Math.abs(Date.now() - DOB.getTime());
    this.age = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365.25);
    this.showMinor = this.age < 18;
    return this.age;
  }
  assignDropdownVal(field, val) {
    this.resumeForm.controls[field].setValue(val);
  }
  navigate() {
    this.formSubmitted = true;
    if(this.resumeForm.valid) {
      this.location.back();
    }
  }
  navigateBack() {
    this.location.back();
  }

}
