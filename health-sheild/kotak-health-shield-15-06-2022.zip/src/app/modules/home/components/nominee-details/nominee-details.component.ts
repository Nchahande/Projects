import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
declare let $: any;

@Component({
  selector: 'app-nominee-details',
  templateUrl: './nominee-details.component.html',
  styleUrls: ['./nominee-details.component.css']
})
export class NomineeDetailsComponent implements OnInit {
  formSubmitted = false;
  nomineeForm1: FormGroup;
  nomineeForm2: FormGroup;
  nomineeResidenceForm1: FormGroup;
  appointeeResidenceForm1:FormGroup;
  additionalResidenceForm1:FormGroup;
  appointeeResidenceForm2:FormGroup;
  showMinorAppointee1 = false;
  showMinorAppointee2 = false;
  additionalNominee = false;
  sameAddressNominee1 = true;
  sameAddressAppointee1 = true;

  sameAddressNominee2 = true;
  sameAddressAppointee2 = false;

  appointeeAge1 = 0;
  nomineeAge1 = 0;
  appointeeAge2 = 0;
  nomineeAge2 = 0;
  currentDate = new Date();
  age = 0;
  minDate = { year: 1920, month: 1, day: 1 };
  maxDate = {year:this.currentDate.getFullYear(), month:this.currentDate.getMonth()+1, day:this.currentDate.getDate()};
  relationships = [
    { label: 'Father', value: 'FA' },
    { label: 'Son', value: 'SO' },
    { label: 'Brother', value: 'BR' },
    { label: 'Grandfather', value: 'GF' },
    { label: 'Grandson', value: 'GS' },
    { label: 'Daughter', value: 'DA' },
    { label: 'Granddaughter', value: 'GD' },
    { label: 'Grandmother', value: 'GM' },
    { label: 'Sister', value: 'SI' },
    { label: 'Wife', value: 'WI' },
    { label: 'Mother', value: 'MO' },
    { label: 'Husband', value: 'HU' }
  ];

  cities = [
    { label: 'Hyderabad', value: 'HYD' },
    { label: 'Bengaluru', value: 'BNG' },
    { label: 'Chennai', value: 'CHE' },
    { label: 'Mumbai', value: 'MUB' }
  ];
  states = [
    { label: 'Andaman and Nicobar Islands', value: 'ANI' },
    { label: 'Andhra Pradesh', value: 'AP' },
    { label: 'Arunachal Pradesh', value: 'ARP' },
    { label: 'Assam', value: 'ASM' },
    { label: 'Bihar', value: 'BR' },
    { label: 'Chandigarh', value: 'CND' },
    { label: 'Chhattisgarh', value: 'CTG' },
    { label: 'Dadra and Nagar Haveli', value: 'DNH' },
    { label: 'Daman and Diu', value: 'DD' },
    { label: 'National Capital Territory of Delhi union territory', value: 'NCR' },
    { label: 'Goa', value: 'GO' },
    { label: 'Gujarat', value: 'GJ' },
    { label: 'Haryana', value: 'HR' },
    { label: 'Himachal Pradesh', value: 'HP' },
    { label: 'Jammu and Kashmir', value: 'JK' },
    { label: 'Jharkhand', value: 'JH' },
    { label: 'Karnataka', value: 'KR' },
    { label: 'Kerala', value: 'KL' },
    { label: 'Ladakh', value: 'LK' },
    { label: 'Lakshadweep', value: 'LX' },
    { label: 'Madhya Pradesh', value: 'MP' },
    { label: 'Maharashtra', value: 'MH' },
    { label: 'Manipur', value: 'MN' },
    { label: 'Meghalaya', value: 'MG' },
    { label: 'Mizoram', value: 'MZ' },
    { label: 'Nagaland', value: 'NG' },
    { label: 'Odisha', value: 'OD' },
    { label: 'Puducherry', value: 'PY' },
    { label: 'Punjab', value: 'PB' },
    { label: 'Rajasthan', value: 'RJ' },
    { label: 'Sikkim', value: 'SM' },
    { label: 'Tamil Nadu', value: 'TN' },
    { label: 'Telangana', value: 'TL' },
    { label: 'Tripura', value: 'TP' },
    { label: 'Uttar Pradesh', value: 'UP' },
    { label: 'Uttarakhand', value: 'UKD' },
    { label: 'West Bengal', value: 'WB' }
  ];
  constructor(private router: Router,
    private fb: FormBuilder) { }

  ngOnInit(): void {
    this.nomineeForm1 = this.fb.group({
      fullName: ['', Validators.required],
      relationship: ['', Validators.required],
      birthdate: ['', Validators.required],
      birthdateAppointee:['', ''],
      appointfullName1: [''],
      appointeeRelationship1: [this.relationships[0].label],
      appointeeBirthdate1: [''],
      sharePercentage: ['50'],
    });
    this.nomineeForm2 = this.fb.group({
      fullName: ['', Validators.required],
      relationship: ['', Validators.required],
      birthdate: ['', Validators.required],
      birthdateAppointee:['', ''],
      appointfullName2: [''],
      appointeeRelationship2: [this.relationships[0].label],
      appointeeBirthdate2: [''],
      sharePercentage: ['50']
    });

    this.nomineeResidenceForm1 = this.fb.group({
      addressLine1: ['', Validators.required],
      addressLine2: ['', Validators.required],
      landmark: ['', ''],
      pincode: new FormControl('', [Validators.required, Validators.pattern('[0-9]{6}')]),
      city: ['', Validators.required],
      state: ['', Validators.required]
    });

    this.appointeeResidenceForm1 = this.fb.group({
      addressLine1: ['', Validators.required],
      addressLine2: ['', Validators.required],
      landmark: ['', ''],
      pincode: new FormControl('', [Validators.required, Validators.pattern('[0-9]{6}')]),
      city: ['', Validators.required],
      state: ['', Validators.required]
    });

    this.additionalResidenceForm1 = this.fb.group({
      addressLine1: ['', Validators.required],
      addressLine2: ['', Validators.required],
      landmark: ['', ''],
      pincode: new FormControl('', [Validators.required, Validators.pattern('[0-9]{6}')]),
      city: ['', Validators.required],
      state: ['', Validators.required]
    });

    this.appointeeResidenceForm2 = this.fb.group({
      addressLine1: ['', Validators.required],
      addressLine2: ['', Validators.required],
      landmark: ['', ''],
      pincode: new FormControl('', [Validators.required, Validators.pattern('[0-9]{6}')]),
      city: ['', Validators.required],
      state: ['', Validators.required]
    });
    
  }


  ageCalcNominee1() {
    const birthdate = this.nomineeForm1.get('birthdate').value;
    this.age = this.ageCalc(birthdate);
    this.showMinorAppointee1 = this.age < 18;
    this.nomineeAge1 = this.age;
  }

  ageCalcAppointee1() {
    const birthdate = this.nomineeForm1.get('birthdateAppointee').value;
    this.age = this.ageCalc(birthdate);
    this.appointeeAge1 = this.age;
  }

  ageCalcNominee2() {
    const birthdate = this.nomineeForm2.get('birthdate').value;
    this.age = this.ageCalc(birthdate);
    this.showMinorAppointee2 = this.age < 18;
    this.nomineeAge2 = this.age;
  }

  ageCalcAppointee2() {
    const birthdate = this.nomineeForm2.get('birthdateAppointee').value;
    this.age = this.ageCalc(birthdate);
    this.appointeeAge2 = this.age;
  }
 
 
  ageCalc(birthdate){
    const DOB = new Date(birthdate.year, birthdate.month - 1, birthdate.day);
    const timeDiff = Math.abs(Date.now() - DOB.getTime());
    this.age = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365.25);
    return this.age;
  }
  assignDropdownVal1(field, val) {
    this.nomineeForm1.controls[field].setValue(val);
  }
  assignDropdownVal2(field, val) {
    this.nomineeForm2.controls[field].setValue(val);
  }
  assignDropdownResi1(field, val) {
    this.nomineeResidenceForm1.controls[field].setValue(val);
  }
  assignDropdownApp1(field, val) {
    this.appointeeResidenceForm1.controls[field].setValue(val);
  }
  assignDropdownAddResi(field, val) {
    this.additionalResidenceForm1.controls[field].setValue(val);
  }
  assignDropdownApp2(field, val) {
    this.appointeeResidenceForm2.controls[field].setValue(val);
  }
  
  
  addNominee() {
    this.additionalNominee = true;
  }
  removeNominee() {
    this.additionalNominee = false;
  }
  navigate() {
    this.formSubmitted = true;
    if (!this.additionalNominee) {
      if (this.nomineeForm1.valid) {
        this.router.navigate(['review-details']);
      } else {
        setTimeout(() => {
          this.moveToError();
        }, 500);
      }
    } else {
      if (this.nomineeForm1.valid && this.nomineeForm2.valid) {
        this.router.navigate(['review-details']);
      } else {
        setTimeout(() => {
          this.moveToError();
        }, 500);
      }
    }

    //this.router.navigate(['payout-details']);
  }
  back() {
    this.router.navigate(['plan-update']);
  }
  moveToError() {
    var elt = $(".errorInput");
    if (elt.length) {
      $('html, body').animate({
        scrollTop: (elt.first().offset().top) - 90
      }, 500);
    }
  }
}
