import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
} from '@angular/forms';
import { DateValidator } from '../../../../shared/date-validator.validator';

declare let $: any;
@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css'],
})
export class LandingPageComponent implements OnInit {
  formSubmitted = false;
  landingForm: FormGroup;
  landingFormMobile: FormGroup;
  gender = '';
  customerAge = 0;
  showMinor = false;

  acceptPolicy = false;
  showTerm = true;
  isMobileProceed = false;

  currentDate = new Date();
  minDate = { year: 1920, month: 1, day: 1 };
  maxDate = {
    year: this.currentDate.getFullYear(),
    month: this.currentDate.getMonth() + 1,
    day: this.currentDate.getDate(),
  };
  userDOB = '13 Sep 1979';
  userAge = 0;

  customOptions: any = {
    loop: true,
    margin: 0,
    nav: false,
    lazyLoad: true,
    autoplay: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    autoplayTimeout: 3000,
    autoplayHoverPause: false,
    dots: true,
    items: 1,
  };

  constructor(private fb: FormBuilder, private router: Router) {}

  ngOnInit(): void {
    this.landingForm = this.fb.group({
      income: ['', [Validators.required]],
    });
    this.landingFormMobile = this.fb.group({
      income: ['', [Validators.required]],
    });
    this.userAge = this.getAge('1979/09/13');
  }

  setGender(val) {
    this.gender = val;
  }
  showMobileForm() {
    this.isMobileProceed = true;
  }

  navigate() {
    this.formSubmitted = true;
    if (!this.isMobileProceed) {
      if (this.landingForm.valid) {
        this.router.navigate(['choose-plan']);
      } else {
        setTimeout(() => {
          this.moveToError();
        }, 500);
      }
    } else {
      if (this.landingFormMobile.valid) {
        this.router.navigate(['choose-plan']);
      } else {
        setTimeout(() => {
          this.moveToErrorMobile();
        }, 500);
      }
    }
  }

  gotoResume() {
    this.router.navigate(['resume-page']);
  }

  validate(evt) {
    var theEvent = evt || window.event;
    var key = theEvent.keyCode || theEvent.which;
    key = String.fromCharCode(key);
    var regex = /[0-9]|\./;
    if (!regex.test(key)) {
      theEvent.returnValue = false;
      if (theEvent.preventDefault) theEvent.preventDefault();
    }
  }

  moveToError() {
    var elt = $('.errorInput');
    if (elt.length) {
      $('html, body').animate(
        {
          scrollTop: elt.first().offset().top - 90,
        },
        500
      );
    }
  }

  moveToErrorMobile() {
    var elt = $('.errorMobile');
    if (elt.length) {
      $('html, body').animate(
        {
          scrollTop: elt.first().offset().top - 120,
        },
        500
      );
    }
  }

  termClicked(status) {
    if (status) {
      this.showTerm = false;
    } else {
      this.showTerm = true;
    }
  }
  getAge(dateString) {
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }
}
