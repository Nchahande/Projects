import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
declare let $: any;

@Component({
  selector: 'app-benefits-discount',
  templateUrl: './benefits-discount.component.html',
  styleUrls: ['./benefits-discount.component.css']
})
export class BenefitsDiscountComponent implements OnInit {
  orgName = '';
  personalShield = false;
  formSubmitted = false;
  annualValues = ["Annually", "Monthly", "Single"];
  annual = this.annualValues[0];
  totalAmount = "₹ 28,587";
  finalAmount = 28587;
  accidentCover = 0;
  hospitalAmount = [
    { label: '₹ 2,000', value: 2000 },
    { label: '₹ 3,000', value: 3000 },
    { label: '₹ 5,000', value: 5000 },
  ];
  selectedHospitalAmount = '₹ 3,000';
  personalAccidentCover = false;
  hospitalCashBenefits = false;
  waiverPremium = false;
  incomeBenefits = false;
  getDiscount = false;

  personalAccidentShiled = false;
  hospitalBenefitShield = false;
  WaiverPremiumShield = false;
  incomeBenefitShiled = false;

  personalAccidentPerDay = 0;
  hospitalBenefitPerDay = 0;
  WaiverPremiumPerDay = 0;
  incomeBenefitPerDay = 0;

  personalAccidentDur = 'year';
  hospitalBenefitDur = 'year';
  WaiverPremiumDur = 'year';
  incomeBenefitDur = 'year';

  chooseBenefitForm:FormGroup;
  discountForm: FormGroup;
  relationshipTypes = [
    { label: 'Individual', value: 'KGLC' },
    { label: 'Group-Non Kotak', value: 'KGIC' },
    { label: 'Kotak Group', value: 'KGIC' },
  ];
  orgNames = [
    { label: 'Kotak Mahindra International', value: 'KMI' },
    { label: 'Kotak Mutual Fund', value: 'KMF' },
    { label: 'Kotak Investment Banking', value: 'KIB' }
  ];
  selectedRelType = '';
  kotakCustomer = false;
  kotakGroup = false;
  kotakGroupEmployee = false;
  selectedOrganisation = '';
  showTerm = false;
  isProceed = true;  

  constructor(private fb: FormBuilder, private router: Router, private location: Location) { }

  ngOnInit(): void {
    this.discountForm = this.fb.group({
      policyNo: ['', Validators.required],
      orgName: ['', Validators.required],
      groupEmpID:['', Validators.required],
    });

    this.chooseBenefitForm = this.fb.group({
      personalAccident: [10, Validators.required],
      hospitalBenefit: [10, Validators.required],
      WaiverPremium: [10, Validators.required],
      incomeBenefit: [10, Validators.required],
    });
  }

  addCover(val) {
    this.finalAmount = this.finalAmount + val;
  }
  minusCover(val) {
    this.finalAmount = this.finalAmount - val;
  }

  changeAnnual(val: string) {
    this.annual = val;
    if (val === "Annually") {
      this.totalAmount = "₹ 10,000";
    } else if (val === "Monthly") {
      this.totalAmount = "₹ 833.33";
    } else {
      this.totalAmount = "₹ 5,00,000";
    }
  }
  calculatePrem() {
    this.formSubmitted = true;

    if (this.personalAccidentShiled || this.hospitalBenefitShield || this.WaiverPremiumShield || this.incomeBenefitShiled) {
      this.isProceed = !this.isProceed;
    } else {
      setTimeout(() => {
        this.moveToError();
      }, 500);
    }
  }
  
  decrease(field) {
    let policyAmount = this.chooseBenefitForm.controls[field].value;
    if (policyAmount > 0) {
      if (policyAmount === 10 || !policyAmount) {
        policyAmount -= 10;
      }
      else {
        policyAmount -= 1;
      }
    }
    this.chooseBenefitForm.controls[field].setValue(policyAmount);
  }
  increase(field) {
    let policyAmount = this.chooseBenefitForm.controls[field].value;
    if (policyAmount === 0 || !policyAmount) {
      policyAmount = policyAmount + 10;
    }
    else {
      policyAmount++;
    }
    this.chooseBenefitForm.controls[field].setValue(policyAmount);
  }
  changeHospitalAmount(amount) {
    this.selectedHospitalAmount = amount;
  }
  toggleBenefits(val) {
    if (val == 'personalAccidentCover') {
      this.personalAccidentCover = !this.personalAccidentCover;
    } else if (val == 'hospitalCashBenefits') {
      this.hospitalCashBenefits = !this.hospitalCashBenefits;
    } else if (val == 'waiverPremium') {
      this.waiverPremium = !this.waiverPremium;
    } else if (val == 'incomeBenefits') {
      this.incomeBenefits = !this.incomeBenefits;
    }
  }
  selectRelationShip(val) {
    this.selectedRelType = val;
    if (val == 'Individual') {
      this.kotakCustomer = true;
      this.kotakGroup = false;
    } else if (val == 'Group-Non Kotak') {
      this.kotakCustomer = false;
      this.kotakGroup = true;
      this.kotakGroupEmployee = false;
    } else {
      this.kotakCustomer = false;
      this.kotakGroup = true;
      this.kotakGroupEmployee = true;
    }
  }
  selectOrganisation(val) {
    this.selectedOrganisation = val;
    this.orgName = val;
  }
  navigate() {
    this.formSubmitted = true; 
    if (this.getDiscount) {
        if(this.selectedRelType !=''){

            if(this.selectedRelType =='Individual'){
                this.discountForm.setValue({
                    policyNo: this.discountForm.get('policyNo').value,
                    orgName: 'null',
                    groupEmpID: 'null',
                });
            }else if(this.selectedRelType =='Group-Non Kotak'){
                this.discountForm.setValue({
                    policyNo: 'null',
                    orgName: this.discountForm.get('orgName').value,
                    groupEmpID: 'null',
                });
            }else{
                this.discountForm.setValue({
                    policyNo: 'null',
                    orgName: this.discountForm.get('orgName').value,
                    groupEmpID: this.discountForm.get('groupEmpID').value,
                });
            }

            if(this.discountForm.valid){
                this.router.navigate(['personal-details']);
            }
        }else{
            this.router.navigate(['personal-details']);
        }
    }else{
      this.router.navigate(['personal-details']);
    }
  }
  back() {
    this.router.navigate(['choose-plan']);
  }
  termClicked(status) {
    if (status) {
      this.showTerm = false;
    } else {
      this.showTerm = true;
    }
  }
  itemsCopy = this.orgNames;
  search(): void {
    let term = this.orgName;
    term = term.toLowerCase();
    this.orgNames = this.itemsCopy.filter(function (tag) {
      return tag.label.toLowerCase().indexOf(term) >= 0;
    });
  }

  updateProceed() {
    this.isProceed = false;
  }

  validateNumber(evt) {
    if (evt.target.value.length <= 2) {
      var theEvent = evt || window.event;
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
      var regex = /^[0-9]\d*$/;
      if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
      }
    } else {
      return false;
    }
  }
  moveToError() {
    var elt = $(".errorMsg");
    if (elt.length) {
      $('html, body').animate({
        scrollTop: (elt.first().offset().top) - 90
      }, 500);
    }
  }
}