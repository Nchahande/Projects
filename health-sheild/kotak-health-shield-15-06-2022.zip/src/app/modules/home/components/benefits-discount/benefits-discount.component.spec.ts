import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BenefitsDiscountComponent } from './benefits-discount.component';

describe('BenefitsDiscountComponent', () => {
  let component: BenefitsDiscountComponent;
  let fixture: ComponentFixture<BenefitsDiscountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BenefitsDiscountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BenefitsDiscountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
