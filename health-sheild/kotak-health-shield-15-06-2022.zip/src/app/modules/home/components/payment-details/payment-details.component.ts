import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-payment-details',
  templateUrl: './payment-details.component.html',
  styleUrls: ['./payment-details.component.css']
})
export class PaymentDetailsComponent implements OnInit {
  formSubmitted = false;
  formFilled = false;
  payingBy = false;
  optForStandingIns = true;
  payAccountType = 'yourBank';
  otherBankForm: FormGroup;
  otherCreditForm: FormGroup;
  opened = false;
  closeResult: string;
  bankAccounts = [
    { label: 'XXXX XXXX XXXX 9012', value: '1' },
    { label: 'XXXX XXXX XXXX 2091', value: '2' },
    { label: 'XXXX XXXX XXXX 8081', value: '3' }
  ];
  creditCards = [
    { label: 'XXXX XXXX XXXX 9012', value: '1' },
    { label: 'XXXX XXXX XXXX 2091', value: '2' },
    { label: 'XXXX XXXX XXXX 8081', value: '3' }
  ];

  insuranceCardSumAssured = '₹ 15,00,000';
  insuranceCardPolicyCover = '55 years';
  premiumCard = 'Monthly';
  
  constructor(
    private router: Router, private fb: FormBuilder, private modalService: NgbModal,
  ) { }

  ngOnInit(): void {
    this.otherBankForm = this.fb.group({
      bankAccount: ['', Validators.required],
    });

    this.otherCreditForm = this.fb.group({
      creditCard: ['', Validators.required],
    });
  }

  open(content) {
    this.opened = true;
    this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title',
      centered: true,
      backdropClass: 'dark-backdrop'
    }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      setTimeout(() => {
        this.navigate();
      }, 1000)
    });
  }
  setAccountType(val) {
    this.payAccountType = val;
    if (this.payAccountType == 'yourBank') {
      this.payingBy = false;
    } else {
      this.payingBy = true;
    }
  }
  navigateToNext() {
    this.formSubmitted = true;
    this.router.navigate(['upload-details']);
  }
  navigate() {
    this.router.navigate(['upload-documents']);
  }
  back() {
    this.router.navigate(['review-details']);
  }
    toggleCheckBox(){
      if(this.optForStandingIns){
        this.formFilled = true;
      } else{
        this.formFilled = false;
      }
  }
  assignBankAccount(field, val) {
    this.otherBankForm.controls[field].setValue(val);
  }
  assignCreditCard(field, val) {
    this.otherCreditForm.controls[field].setValue(val);
  }

  getInsurance(v){
    this.insuranceCardSumAssured = v;
  }
  getPolicyCover(v){
    this.insuranceCardPolicyCover = v;
  }
  onPremiumCard(v){
    this.premiumCard = v;
  }
  
}
