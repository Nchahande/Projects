import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-congrats-page',
  templateUrl: './congrats-page.component.html',
  styleUrls: ['./congrats-page.component.css']
})
export class CongratsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
