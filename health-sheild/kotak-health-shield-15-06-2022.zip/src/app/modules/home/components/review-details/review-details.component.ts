import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
declare let $: any;


@Component({
  selector: 'app-review-details',
  templateUrl: './review-details.component.html',
  styleUrls: ['./review-details.component.css']
})
export class ReviewDetailsComponent implements OnInit {
  formSubmitted = false;
  reviewForm: FormGroup;
  opened = false;
  closeResult: string;
  proposalFormAccepted = false;
  covidDecAccepted = false;
  constructor(
    private location: Location,
    private router: Router,
    private modalService: NgbModal,
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    this.reviewForm = this.fb.group({
    });
  }

  open(content) {
    this.opened = true;
    this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title',
      centered: true,
      size: 'lg',
      backdropClass: 'dark-backdrop'
    }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  openConditions(event, content, getVar) {
    this[getVar] = event.target.checked;
    if (event.target.checked) {
      this.open(content);
    }
  }

  navigate() {
    this.formSubmitted = true;
    /* if (this.proposalFormAccepted && this.covidDecAccepted) { */
    if (this.proposalFormAccepted) {
      this.router.navigate(['payment-details']);
    } else {
      setTimeout(() => {
        this.moveToError();
      }, 500);
    }
  }
  back() {
    this.router.navigate(['nominee-details']);
  }
  moveToError() {
    var elt = $(".errorMsg");
    if (elt.length) {
      $('html, body').animate({
        scrollTop: (elt.first().offset().top) - 90
      }, 500);
    }
  }
  proposalModalUncheck() {
    this.proposalFormAccepted = false;
  }
  fatcaFormAcceptedModalUncheck() {
    this.covidDecAccepted = false;
  }
}
