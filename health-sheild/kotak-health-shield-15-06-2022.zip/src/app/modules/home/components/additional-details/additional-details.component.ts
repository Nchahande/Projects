import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
declare let $: any;

@Component({
  selector: 'app-additional-details',
  templateUrl: './additional-details.component.html',
  styleUrls: ['./additional-details.component.css']
})
export class AdditionalDetailsComponent implements OnInit {
  formSubmitted = false;
  additionalDetailsForm: FormGroup;
  opened = false;
  anyDisease = '';
  closeResult: string;
  heightList = [
    { label: '4 ft 0 in', value: 4.0 },
    { label: '4 ft 1 inch', value: 4.1 },
    { label: '4 ft 2 inch', value: 4.2 },
    { label: '4 ft 3 inch', value: 4.3 },
    { label: '4 ft 4 inch', value: 4.4 },
    { label: '4 ft 5 inch', value: 4.5 },
    { label: '4 ft 6 inch', value: 4.6 },
    { label: '4 ft 7 inch', value: 4.7 },
    { label: '4 ft 8 inch', value: 4.8 },
    { label: '4 ft 9 inch', value: 4.9 },
    { label: '4 ft 10 inch', value: 4.10 },
    { label: '4 ft 11 inch', value: 4.11 },
    { label: '5 ft 0 inch', value: 5.0 },
    { label: '5 ft 1 inch', value: 5.1 },
    { label: '5 ft 2 inch', value: 5.2 },
    { label: '5 ft 3 inch', value: 5.3 },
    { label: '5 ft 4 inch', value: 5.4 },
    { label: '5 ft 5 inch', value: 5.5 },
    { label: '5 ft 6 inch', value: 5.6 },
    { label: '5 ft 7 inch', value: 5.7 },
    { label: '5 ft 8 inch', value: 5.8 },
    { label: '5 ft 9 inch', value: 5.9 },
    { label: '5 ft 10 inch', value: 5.10 },
    { label: '5 ft 11 inch', value: 5.11 },
    { label: '6 ft 0 inch', value: 6.0 },
    { label: '6 ft 1 inch', value: 6.1 },
    { label: '6 ft 2 inch', value: 6.2 },
    { label: '6 ft 3 inch', value: 6.3 },
    { label: '6 ft 4 inch', value: 6.4 },
    { label: '6 ft 5 inch', value: 6.5 }
  ]
  diseaseList = [
    { id: 1, name: 'Heart Disease' },
    { id: 2, name: 'Stroke' },
    { id: 3, name: 'High Blood Pressure' },
    { id: 4, name: 'Diabetes Mellitus' },
    { id: 5, name: 'Cancer' },
    { id: 6, name: 'Kidney Disease' },
    { id: 7, name: 'Paralysis or any other hereditary / familial disorders' },
    { id: 8, name: 'Tuberculosis or any contagious diseases such as Hepatitis, AIDS / HIV' }
  ]

  constructor(private router: Router, private fb: FormBuilder, private modalService: NgbModal) { }

  ngOnInit(): void {
    this.additionalDetailsForm = this.fb.group({
      height: ['', Validators.required],
      weight: ['', Validators.required],
      smoker: ['', Validators.required],
      tobacco: ['', Validators.required],
      alcohol: ['', Validators.required],
      narcotics: ['', Validators.required],
      hospitalized: ['', Validators.required],
      hiv: ['', Validators.required],
      familySuffered: ['', Validators.required],
      diseasesList: ['']
    });
  }
  assignDropdownVal(field, val) {
    this.additionalDetailsForm.controls[field].setValue(val);
  }
  dec() {
    let weight = this.additionalDetailsForm.controls['weight'].value;
    if (weight > 30) {
      weight--;
      this.additionalDetailsForm.controls['weight'].setValue(weight);
    }
  }

  inc() {
    let weight = this.additionalDetailsForm.controls['weight'].value;
    weight++;
    this.additionalDetailsForm.controls['weight'].setValue(weight);
  }
  navigate() {
    this.formSubmitted = true;
    if (this.additionalDetailsForm.valid) {
      this.router.navigate(['policy-health']);
    } else {
      setTimeout(() => {
        this.moveToError();
      }, 500);
    }
  }
  back() {
    this.router.navigate(['personal-details']);
  }
  open(content) {
    this.opened = true;
    this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title',
      centered: true,
      backdropClass: 'dark-backdrop'
    }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  selectSuffered(val) {
    console.log(val);
    this.anyDisease = val;
    
  }
  moveToError() {
    var elt = $(".errorInput");
    if (elt.length) {
      $('html, body').animate({
        scrollTop: (elt.first().offset().top) - 90
      }, 500);
    } else {
      var elt1 = $(".errorMsg");
      if (elt1.length) {
        $('html, body').animate({
          scrollTop: (elt1.first().offset().top) - 100
        }, 500);
      }
    }
  }
}
