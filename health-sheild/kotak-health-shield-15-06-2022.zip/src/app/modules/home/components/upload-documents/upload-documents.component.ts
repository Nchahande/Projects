import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-upload-documents',
  templateUrl: './upload-documents.component.html',
  styleUrls: ['./upload-documents.component.css']
})
export class UploadDocumentsComponent implements OnInit {

  constructor(private router: Router) { }
  documents = [
    { label: 'Passport', value: 'Passport' },
    { label: 'Voter ID', value: 'Voter' },
    { label: 'Driving License', value: 'Driving' },
    { label: 'Aadhar Card', value: 'Aadhar' },
    { label: 'NERGA Job Card', value: 'NERGA' }
  ];

  documents1 = [
    { label: 'Passport', value: 'Passport' },
    { label: 'Voter ID', value: 'Voter' },
    { label: 'Driving License', value: 'Driving' },
    { label: 'Aadhar Card', value: 'Aadhar' },
  ];

  documents2 = [
    { label: 'Bank Statement', value: 'Bank' },
    { label: 'Last 3 Months Salary Slip', value: 'Salary' },
    { label: 'Latest Audit P&L Acc. Statement', value: 'Audit' },
    { label: 'IT Return', value: 'IT' },
    { label: 'Form 16', value: 'Form16' },
    { label: 'Employers Certificate', value: 'EmpCertificate' },
  ];

  PermanentProof = '';
  PermanentProofCount = 1;
  
  ageProof = '';
  ageProofDoc2Count = 1;

  IDProof = '';
  IDProofDoc2Count = 1;

  AddTPProof = '';
  AddTPProofDoc2Count = 1;

  IncomeTPProof = '';
  IncomeTPProofCount = 1;

  ngOnInit(): void {
    //this.PermanentProof = this.documents[0].label;
    this.ageProof = this.documents1[0].label;
    this.IDProof = this.documents[0].label;
    this.AddTPProof = this.documents[0].label;
    this.IncomeTPProof = this.documents2[0].label;

    $('.imageClose').click(function () {
      console.log($(this).parent().prev('.input__file__container').css('display', 'flex'));
      $(this).parent('.input__file__details').css('display', 'none');
      $(this).parent().prev('.input__file__container').css('display', 'block');
    });
  }
  navigate() {
    this.router.navigate(['success']);
  }
  back() {
    this.router.navigate(['payment-details']);
  }
  
  addPermanentProof(e) {
    if (e == 1) {
      this.PermanentProofCount = this.PermanentProofCount + 1;
    } else {
      this.PermanentProofCount = this.PermanentProofCount - 1;
    }
  }
  addAgeProofDoc2(e) {
    if (e == 1) {
      this.ageProofDoc2Count = this.ageProofDoc2Count + 1;
    } else {
      this.ageProofDoc2Count = this.ageProofDoc2Count - 1;
    }
  }

  addIDProofDoc2(e) {
    if (e == 1) {
      this.IDProofDoc2Count = this.IDProofDoc2Count + 1;
    } else {
      this.IDProofDoc2Count = this.IDProofDoc2Count - 1;
    }
  }

  addAddTPProof(e) {
    if (e == 1) {
      this.AddTPProofDoc2Count = this.AddTPProofDoc2Count + 1;
    } else {
      this.AddTPProofDoc2Count = this.AddTPProofDoc2Count - 1;
    }
  }

  addIncomeTPProof(e) {
    if (e == 1) {
      this.IncomeTPProofCount = this.IncomeTPProofCount + 1;
    } else {
      this.IncomeTPProofCount = this.IncomeTPProofCount - 1;
    }
  }

  uploadFile(event: Event) {
    const element = event.currentTarget as HTMLInputElement;
    let fileList: FileList | null = element.files;
    if (fileList) {
      $('#' + element.id).parent().css('display', 'none');
      $('#' + element.id).parent().next('.input__file__details').css('display', 'flex');
      $('#' + element.id).parent().next().find('.imageDetails p').html(fileList[0].name);
    }
  }

  deleteUpload(event: Event) {
    const element = event.currentTarget as HTMLInputElement;
    console.log($('#' + element.className).parent());
  }
  assignPermanentProof(val) {
    this.PermanentProof = val;
  }

  assignAgeProof(val) {
    this.ageProof = val;
  }

  assignIDProof(val) {
    this.IDProof = val;
  }

  assignAddProofTP(val) {
    this.AddTPProof = val;
  }
  assignIncomeProofTP(val) {
    this.IncomeTPProof = val;
  }
}
