import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
declare let $: any;

@Component({
  selector: 'app-other-details',
  templateUrl: './other-details.component.html',
  styleUrls: ['./other-details.component.css']
})
export class OtherDetailsComponent implements OnInit {
  formSubmitted = false;
  otherDetailsForm: FormGroup;
  constructor(private router: Router,
    private fb: FormBuilder) { }

  ngOnInit(): void {
    this.otherDetailsForm = this.fb.group({
      otherCitizen: ['', Validators.required],
      otherTaxResident: ['', Validators.required],
      greenCardHolder: ['', Validators.required],
      criminalHistory: ['', Validators.required],
      politicallyExposed: ['', Validators.required]
    });
  }
  navigate() {
    this.formSubmitted = true;
    if (this.otherDetailsForm.valid) {
      this.router.navigate(['plan-update']);
    } else {
      setTimeout(() => {
        this.moveToError();
      }, 500);
    }
  }
  back() {
    this.router.navigate(['personal-health']);
  }
  moveToError() {
    var elt = $(".errorMsg");
    if (elt.length) {
      $('html, body').animate({
        scrollTop: (elt.first().offset().top) - 100
      }, 500);
    }
  }
}
