import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-plan-update',
  templateUrl: './plan-update.component.html',
  styleUrls: ['./plan-update.component.css'],
})
export class PlanUpdateComponent implements OnInit {
  choosePlanForm: FormGroup;
  chooseBenefitForm: FormGroup;

  formSubmitted = false;
  cancerShiled = false;
  cardiacShield = false;

  personalAccidentShiled = false;
  WaiverPremiumShield = false;

  showTerm = true;

  constructor(private router: Router, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.choosePlanForm = this.fb.group({
      cancer: [10, Validators.required],
      cardiac: [10, Validators.required],
    });

    this.chooseBenefitForm = this.fb.group({
      personalAccident: [10, Validators.required],
      hospitalBenefit: [10, Validators.required],
      WaiverPremium: [10, Validators.required],
      incomeBenefit: [10, Validators.required],
    });
  }
  navigate() {
    this.router.navigate(['nominee-details']);
  }
  back() {
    this.router.navigate(['other-details']);
  }
  decrease(field) {
    let policyAmount = this.choosePlanForm.controls[field].value;
    if (policyAmount > 0) {
      if (policyAmount === 10 || !policyAmount) {
        policyAmount -= 10;
      } else {
        policyAmount -= 1;
      }
    }
    this.choosePlanForm.controls[field].setValue(policyAmount);
  }
  increase(field) {
    let policyAmount = this.choosePlanForm.controls[field].value;
    if (policyAmount === 0 || !policyAmount) {
      policyAmount = policyAmount + 10;
    } else {
      policyAmount++;
    }
    this.choosePlanForm.controls[field].setValue(policyAmount);
  }
  validateNumber(evt) {
    if (evt.target.value.length <= 2) {
      var theEvent = evt || window.event;
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
      var regex = /^[0-9]\d*$/;
      if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
      }
    } else {
      return false;
    }
  }

  termClicked(status) {
    if (status) {
      this.showTerm = false;
    } else {
      this.showTerm = true;
    }
  }
}
