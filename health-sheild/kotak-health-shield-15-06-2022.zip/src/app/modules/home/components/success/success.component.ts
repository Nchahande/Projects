import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {
  formSubmitted = false;
  feedbackNotGiven = true;
  isRefer = false;
  feedbackNo = 0;
  referForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.referForm = this.fb.group({
      empNo: ['', [Validators.required]],
    });
  }

  referSubmit() {
    this.formSubmitted = true;
    if (this.referForm.valid) {
      console.log('submitted!');
    }
  }

  customOptions: any = {
    loop: true,
    margin: 0,
    nav: true,
    navText: ["", ""],
    lazyLoad: true,
    autoplay: false,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    autoplayTimeout: 3000,
    autoplayHoverPause: false,
    dots: false,
    items: 1,
  }
  selectFeedback() {
    this.feedbackNotGiven = false;
  }

  getFeedbackItem(val) {
    this.feedbackNo = val;
    this.feedbackNotGiven = false;
  }
  checkRefer(val){
    if(val=='Yes'){
      this.isRefer = true;
    }else{
      this.isRefer = false;
    }
  }
}

