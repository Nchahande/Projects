import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
declare let $: any;


@Component({
  selector: 'app-personal-details',
  templateUrl: './personal-details.component.html',
  styleUrls: ['./personal-details.component.css']
})
export class PersonalDetailsComponent implements OnInit {
  formSubmitted = false;
  residentialForm: FormGroup;
  resiStatuses = [
    { label: 'Resident Individual', value: 'Resident Individual' },
    { label: 'NRI', value: 'NRI' },
    { label: 'PIO', value: 'PIO' },
    { label: 'Foreign National', value: 'Foreign National' }
  ];
  maritalStatuses = [
    { label: 'Unmarried', value: 'Unmarried' },
    { label: 'Married', value: 'Married' },
    { label: 'Divorced', value: 'Divorced' },
    { label: 'Widow', value: 'Widow' }
  ];
  educationStatuses = [
    { label: `Professional`, value: 'Professional' },
    { label: `Post-Graduate`, value: `Post-Graduate` },
    { label: `Graduate`, value: `Graduate` },
    { label: 'Diploma', value: 'Diploma' },
    { label: '12th Pass', value: '12th Pass' },
    { label: '10th Pass', value: '10th Pass' },
    { label: 'Below 10th', value: 'Below 10th' }
  ];
  occuStatuses = [
    { label: 'Professional', value: 'Professional' },
    { label: 'Self Employed', value: 'Self Employed' },
    { label: 'Student', value: 'Student' },
    { label: 'Housewife', value: 'Housewife' },
    { label: 'Retired', value: 'Retired' },
    { label: 'Salaried', value: 'Salaried' },
  ];

  constructor(private router: Router, private fb: FormBuilder, private modalService: NgbModal) { }

  ngOnInit(): void {
    this.residentialForm = this.fb.group({
      residentialStatus: ['Resident Individual', Validators.required],
      pincode: ['121212',],
      mothersName: ['', Validators.required],
      fatherSpouseName: ['', Validators.required],
      maritalStatus: ['', Validators.required],
      education: ['', Validators.required],
      occupation: ['', Validators.required],
      panNo: ['', Validators.required]
    });
  }
  assignDropdownVal(field, val) {
    this.residentialForm.controls[field].setValue(val);
  }
  navigate() {
    this.formSubmitted = true;
    if (this.residentialForm.valid) {
      this.router.navigate(['additional-details']);
    } else {
      setTimeout(() => {
        this.moveToError();
      }, 500);
    }
  }
  back() {
    this.router.navigate(['benefits-discount']);
  }
  url = 'assets/images/camera.svg';
  imageUploaded = false;
  imgOriginal = false;
  onSelectFile(event) {
    this.imageUploaded = true;
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        this.url = event.target.result as string;
      }
    }
  }
  unselectFile() {
    this.imageUploaded = false;
    this.url = 'assets/images/camera.svg';
  }

  moveToError() {
    var elt = $(".errorInput");
    if (elt.length) {
      $('html, body').animate({
        scrollTop: (elt.first().offset().top) - 90
      }, 500);
    }
  }
}
