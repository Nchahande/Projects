import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
declare let $: any;


@Component({
  selector: 'app-payout-details',
  templateUrl: './payout-details.component.html',
  styleUrls: ['./payout-details.component.css']
})
export class PayoutDetailsComponent implements OnInit {
  formSubmitted = false;
  landingForm: FormGroup;
  accountType = 'saving';
  paymentForm: FormGroup;
  opened = false;
  closeResult: string;
  formIsInvalid = true;
  bankAccounts = [
    { label: 'XXXX XXXX XXXX 9012', value: '1' },
    { label: 'XXXX XXXX XXXX 2091', value: '2' },
    { label: 'XXXX XXXX XXXX 8081', value: '3' }
  ];
  constructor(private fb: FormBuilder,
    private location: Location,
    private modalService: NgbModal,
    private router: Router) { }

  ngOnInit(): void {
    this.paymentForm = this.fb.group({
      accountNo: ['', Validators.required],
    });
  }
  setAccountType(val) {
    this.accountType = val;
  }
  displayModal() {
    if (this.paymentForm.valid) {
      this.formIsInvalid = false;
    }
  }
  navigate() {
    this.formSubmitted = true;
    if (this.paymentForm.valid) {
      this.formIsInvalid = false;
      this.router.navigate(['review-details']);
    } else {
      this.formIsInvalid = true;
      setTimeout(() => {
        this.moveToError();
      }, 500);
    }
  }
  back() {
    this.router.navigate(['nominee-details']);
  }
  assignBankAccount(field, val) {
    this.paymentForm.controls[field].setValue(val);
  }
  open(content) {
    this.opened = true;
    this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title',
      centered: true,
      backdropClass: 'dark-backdrop'
    }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      setTimeout(() => {
        this.navigate();
      }, 1000);
    });
  }

  openConditions(content) {
    if (!this.opened) {
      this.opened = true;
      this.open(content);
    }
  }
  moveToError() {
    var elt = $(".errorInput");
    if (elt.length) {
      $('html, body').animate({
        scrollTop: (elt.first().offset().top) - 90
      }, 500);
    }
  }
}
