import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-upload-details',
  templateUrl: './upload-details.component.html',
  styleUrls: ['./upload-details.component.css']
})
export class UploadDetailsComponent implements OnInit {
  showPANCard = true
  showPermenantAddress = true;
  showAgeProof = false
  showIDProof = false;
  addressProofs = [
    {label: 'Voter ID Card', value: 'voter-id-card'},
    {label: 'Driving License', value: 'dl'},
  ];
  uploadDetailsForm: FormGroup;
  constructor(private location: Location, private router: Router,private fb: FormBuilder) { }

  ngOnInit(): void {
    this.uploadDetailsForm = this.fb.group({
      adProof: ['', Validators.required]
    });
  }

  navigateBack() {
    this.location.back();
  }

  navigate() {
    this.router.navigate(['congrats-page']);
  }
  assignDropdownVal(field, val) {
    this.uploadDetailsForm.controls[field].setValue(val);
  }

  showPan(){
    this.showPANCard = !this.showPANCard;
  }
  showPermenant(){
    this.showPermenantAddress = !this.showPermenantAddress;
  }
  showAge(){
    this.showAgeProof = !this.showAgeProof;
  }
  showID(){
    this.showIDProof = !this.showIDProof;
  }
}
