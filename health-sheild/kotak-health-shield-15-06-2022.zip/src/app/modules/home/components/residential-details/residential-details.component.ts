import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
let GlobalThis;
declare let $: any;

@Component({
  selector: 'app-residential-details',
  templateUrl: './residential-details.component.html',
  styleUrls: ['./residential-details.component.css']
})
export class ResidentialDetailsComponent implements OnInit {
  formSubmitted = false;
  residenceDetailsForm: FormGroup;
  permenantForm: FormGroup;

  cities = [
    { label: 'Hyderabad', value: 'HYD' },
    { label: 'Bengaluru', value: 'BNG' },
    { label: 'Chennai', value: 'CHE' },
    { label: 'Mumbai', value: 'MUB' }
  ];
  states = [
    { label: 'Andaman and Nicobar Islands', value: 'ANI' },
    { label: 'Andhra Pradesh', value: 'AP' },
    { label: 'Arunachal Pradesh', value: 'ARP' },
    { label: 'Assam', value: 'ASM' },
    { label: 'Bihar', value: 'BR' },
    { label: 'Chandigarh', value: 'CND' },
    { label: 'Chhattisgarh', value: 'CTG' },
    { label: 'Dadra and Nagar Haveli', value: 'DNH' },
    { label: 'Daman and Diu', value: 'DD' },
    { label: 'National Capital Territory of Delhi union territory', value: 'NCR' },
    { label: 'Goa', value: 'GO' },
    { label: 'Gujarat', value: 'GJ' },
    { label: 'Haryana', value: 'HR' },
    { label: 'Himachal Pradesh', value: 'HP' },
    { label: 'Jammu and Kashmir', value: 'JK' },
    { label: 'Jharkhand', value: 'JH' },
    { label: 'Karnataka', value: 'KR' },
    { label: 'Kerala', value: 'KL' },
    { label: 'Ladakh', value: 'LK' },
    { label: 'Lakshadweep', value: 'LX' },
    { label: 'Madhya Pradesh', value: 'MP' },
    { label: 'Maharashtra', value: 'MH' },
    { label: 'Manipur', value: 'MN' },
    { label: 'Meghalaya', value: 'MG' },
    { label: 'Mizoram', value: 'MZ' },
    { label: 'Nagaland', value: 'NG' },
    { label: 'Odisha', value: 'OD' },
    { label: 'Puducherry', value: 'PY' },
    { label: 'Punjab', value: 'PB' },
    { label: 'Rajasthan', value: 'RJ' },
    { label: 'Sikkim', value: 'SM' },
    { label: 'Tamil Nadu', value: 'TN' },
    { label: 'Telangana', value: 'TL' },
    { label: 'Tripura', value: 'TP' },
    { label: 'Uttar Pradesh', value: 'UP' },
    { label: 'Uttarakhand', value: 'UKD' },
    { label: 'West Bengal', value: 'WB' }
  ];
  sameAddress = true;

  constructor(private router: Router,
    private fb: FormBuilder) { }

  ngOnInit(): void {
    this.residenceDetailsForm = this.fb.group({
      addressLine1: ['', Validators.required],
      addressLine2: ['', Validators.required],
      landmark: ['', ''],
      pincode: new FormControl('', [Validators.required, Validators.pattern('[0-9]{6}')]),
      city: ['', Validators.required],
      state: ['', Validators.required]
    });
    this.permenantForm = this.fb.group({
      permAddressLine1: ['', Validators.required],
      permAddressLine2: ['', Validators.required],
      permLandmark: ['', ''],
      permPincode: new FormControl('', [Validators.required, Validators.pattern('[0-9]{6}')]),
      permCity: ['', Validators.required],
      permState: ['', Validators.required]
    });

  }
  assignDropdownVal(field, val) {
    this.residenceDetailsForm.controls[field].setValue(val);
  }
  assignDropdownVal1(field, val) {
    this.permenantForm.controls[field].setValue(val);
  }
  navigate() {
    this.formSubmitted = true;
    if (this.sameAddress) {
      if (this.residenceDetailsForm.valid) {
        this.router.navigate(['nominee-details']);
      } else {
        setTimeout(() => {
          this.moveToError();
        }, 500);
      }
    } else {
      if (this.residenceDetailsForm.valid && this.permenantForm.valid) {
        this.router.navigate(['nominee-details']);
      } else {
        setTimeout(() => {
          this.moveToError();
        }, 500);
      }
    }
  }
  back() {
    this.router.navigate(['plan-update']);
  }
  moveToError() {
    var elt = $(".errorInput");
    if (elt.length) {
      $('html, body').animate({
        scrollTop: (elt.first().offset().top) - 90
      }, 500);
    }
  }
}
