import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyHealthComponent } from './policy-health.component';

describe('PolicyHealthComponent', () => {
  let component: PolicyHealthComponent;
  let fixture: ComponentFixture<PolicyHealthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PolicyHealthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
