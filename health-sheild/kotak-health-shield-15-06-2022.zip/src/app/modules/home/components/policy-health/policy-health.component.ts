import { Component, OnInit, Input, ChangeDetectorRef, AfterViewChecked, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
declare let $: any;

@Component({
  selector: 'app-policy-health',
  templateUrl: './policy-health.component.html',
  styleUrls: ['./policy-health.component.css']
})
export class PolicyHealthComponent implements OnInit, AfterViewChecked {
  @ViewChild('criticalIllnessCover') input;

  formSubmitted = false;
  criticalIllnessForm: FormGroup;
  covidForm: FormGroup;
  criticalIllnessCoverForm: FormGroup;
  vaccineDoseForm: FormGroup;
  sarsCovid19Form: FormGroup;
  travelDetailsForm: FormGroup;
  quarantineDetailsForm: FormGroup;
  criticalIllnessFormFilled = false;
  covidFormFilled = false;
  opened = false;
  yesToDose1:boolean =false;
  yesToDose2:boolean = false;
  reasonOfDose1:boolean = false;
  reasonOfDose2:boolean = false;
  closeResult: string;
  symptomState = [];
  healthSymptoms = false;
  selectedRelType = '';

  symptoms = [
    { id: 1, title: 'Fever' },
    { id: 2, title: 'Cough or sore throat' },
    { id: 3, title: 'Shortness of breath/ Difficulty in breathing' },
    { id: 4, title: 'Malaise (discomfort or uneasiness due to illness/ flu-like tiredness)' },
    { id: 5, title: 'Rhinorrhoea (mucus discharge from the nose)' },
    { id: 6, title: 'Gastro-intestinal symptoms (nausea/ vomiting/ diarrhoea)' },
  ]

  relationshipTypes = [
    { label: 'Parents', value: 'KGLC' },
    { label: 'Parents in Law', value: 'KGIC' },
    { label: 'Spouse', value: 'KGIC' },
    { label: 'Children', value: 'KGLC' },
    { label: 'Siblings', value: 'KGIC' },
    { label: 'Grand Father', value: 'KGIC' },
    { label: 'Grand Mother', value: 'KGIC' },
    { label: 'Other', value: 'KGIC' }
  ];

  constructor(private fb: FormBuilder,
    private modalService: NgbModal,
    private chRef: ChangeDetectorRef, private router: Router) {
    for (let i = 0; i < 7; i++) {
      this.symptomState[i] = false;
    }
  }

  ngOnInit(): void {
    this.criticalIllnessForm = this.fb.group({
      ciCover: ['', Validators.required],
      ciClaim: ['', Validators.required],
      ciDeclined: ['', Validators.required],
      insuranceUpdated: ['', Validators.required]
    });

    this.covidForm = this.fb.group({
      goodHealth: ['', Validators.required],
      symptoms: ['', Validators.required],
      travelledAbroad: ['', Validators.required],
      willTravel: ['', Validators.required],
      quarantined: ['', Validators.required],
      covidPositive: ['', Validators.required],
      covidInvestigate: ['', Validators.required]
    });

    this.criticalIllnessCoverForm = this.fb.group({
      typePolicy: ['', Validators.required],
      insurancePeriod: ['', Validators.required],
      insuranceCompany: ['', Validators.required],
      baseSumAssured: ['', Validators.required],
    });
    this.vaccineDoseForm = this.fb.group({
      vaccineDose1: ['', Validators.required],
      vaccineDose2: ['', Validators.required],
      deptDate: ['', Validators.required],
      deptDate2: ['', Validators.required],
      nameVaccine: ['', Validators.required],
      nameVaccine2: ['', Validators.required],
      reasonVaccine1: ['', Validators.required],
      reasonVaccine2: ['', Validators.required]
    });


    this.sarsCovid19Form = this.fb.group({
    });


    this.travelDetailsForm = this.fb.group({
      countryName: [''],
      cityName: [''],
      deptDate: [''],
      arriveDate: [''],
      travelPurpose: [''],
    });
    this.quarantineDetailsForm = this.fb.group({
      birthdate: [''],
      travelPurpose: [''],
    });
  }
  criticalIllness() {

    /*  if (this.criticalIllnessForm.controls['ciCover'].value) {
       this.open(this.input);
     } */
    if (this.criticalIllnessForm.controls['ciCover'].value && this.criticalIllnessForm.controls['ciClaim'].value && this.criticalIllnessForm.controls['ciDeclined'].value && this.criticalIllnessForm.controls['insuranceUpdated'].value) {
      this.criticalIllnessFormFilled = true;

    } else {
      this.criticalIllnessFormFilled = false;
    }
  }
  covidQAndA() {
    if (this.covidForm.controls['goodHealth'].value
      && this.covidForm.controls['symptoms'].value
      && this.covidForm.controls['travelledAbroad'].value
      && this.covidForm.controls['willTravel'].value
      && this.covidForm.controls['quarantined'].value
      && this.covidForm.controls['covidPositive'].value
      && this.covidForm.controls['covidInvestigate'].value
    ) {
      this.covidFormFilled = true;
    } else {
      this.covidFormFilled = false;
    }
  }


  navigate() {
    this.formSubmitted = true;
    if (this.criticalIllnessForm.valid && this.covidForm.valid) {
      this.router.navigate(['personal-health']);
    } else {
      setTimeout(() => {
        this.moveToError();
      }, 500);
    }
  }
  back() {
    this.router.navigate(['additional-details']);
  }
  tp(content) {
    this.opened = true;
    this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title',
      centered: true,
      size: 'lg',
      backdropClass: 'dark-backdrop'
    }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  moveToError() {
    var elt = $(".errorMsg");
    if (elt.length) {
      $('html, body').animate({
        scrollTop: (elt.first().offset().top) - 100
      }, 500);
    }
  }

  open(content) {

    this.opened = true;
    this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title',
      centered: true,
      size: 'lg',
      backdropClass: 'dark-backdrop'
    }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  ngAfterViewChecked() {
    if (this.symptomState[7]) {
      for (let i = 1; i <= 6; i++) {
        if (this.symptomState[i]) {
          this.symptomState[i] = false;
        }
      }
      this.healthSymptoms = false;
    } else {
      // for(var i=1; i<=6; i++) {
      //   if(this.symptomState[i]) {
      //     this.healthSymptoms = true;
      //   } else{
      //     this.healthSymptoms = false;
      //   }
      // }
      this.healthSymptoms = true;
      if (this.symptomState[1]) {
        this.healthSymptoms = true;
        this.symptomState[7] = false;
      } else if (this.symptomState[2]) {
        this.healthSymptoms = true;
        this.symptomState[7] = false;
      } else if (this.symptomState[3]) {
        this.healthSymptoms = true;
        this.symptomState[7] = false;
      } else if (this.symptomState[4]) {
        this.healthSymptoms = true;
        this.symptomState[7] = false;
      } else if (this.symptomState[5]) {
        this.healthSymptoms = true;
        this.symptomState[7] = false;
      } else if (this.symptomState[6]) {
        this.healthSymptoms = true;
        this.symptomState[7] = false;
      } else {
        this.healthSymptoms = false;
      }
    }
    this.chRef.detectChanges();
  }
  criticalCoverSubmit() {
    this.formSubmitted = true;
    if (this.criticalIllnessCoverForm.valid) {
      this.opened = false;
    }
  }

  showFormDose1() {
    this.yesToDose1 = true;
    this.reasonOfDose1 = false;
  }
  reasonDose1() {
    this.yesToDose1 = false;
    this.reasonOfDose1 = true;
  }

  showFormDose2() {
    this.yesToDose2 = true;
    this.reasonOfDose2 = false;
  }
  reasonDose2() {
    this.yesToDose2 = false;
    this.reasonOfDose2 = true;
  }

  selectRelationShip(val) {
    this.selectedRelType = val;
  }
}
