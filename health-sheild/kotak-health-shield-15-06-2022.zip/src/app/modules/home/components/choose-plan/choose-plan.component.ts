import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

declare let $: any;

@Component({
  selector: 'app-choose-plan',
  templateUrl: './choose-plan.component.html',
  styleUrls: ['./choose-plan.component.css'],
})
export class ChoosePlanComponent implements OnInit {
  choosePlanForm: FormGroup;
  formSubmitted = false;
  isProceed = false;
  planYears = '45 Years';

  cancerShiled = false;
  cardiacShield = false;
  livoShield = false;
  neuroShiled = false;

  cancerPerDay = 0;
  cardiacPerDay = 0;
  livoPerDay = 0;
  neuroPerDay = 0;

  annualValues = ['Annually', 'Monthly', 'Single'];
  annual = this.annualValues[0];
  totalAmount = '₹ 10,000';
  showTerm = false;
  insuranceCardSumAssured = '₹ 15,00,000';
  insuranceCardPolicyCover = '55 years';
  premiumCard = 'Monthly';

  showMonthPremium = false;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    this.choosePlanForm = this.fb.group({
      policyDuration: ['', Validators.required],
      cancer: [10, Validators.required],
      cardiac: [10, Validators.required],
      livo: [10, Validators.required],
      neuro: [10, Validators.required],
    });
    $('.tooltiptextCustom').click(function () {
      $(this).css('visibility', 'hidden');
      $(this).css('opacity', '0');
    });
    $('.tooltiptextCustom').mouseout(function () {
      $('.tooltiptextCustom').attr('style', '');
    });
  }

  decrease(field) {
    let policyAmount = this.choosePlanForm.controls[field].value;
    if (policyAmount > 0) {
      if (policyAmount === 10 || !policyAmount) {
        policyAmount -= 10;
      } else {
        policyAmount -= 1;
      }
    }
    this.choosePlanForm.controls[field].setValue(policyAmount);
    console.log(
      'this.detailsTwoForm.controls[field].value ' +
        this.choosePlanForm.controls[field].value
    );
    this.checkForDisplay(policyAmount, field);
    this.isProceed = false;
  }
  increase(field) {
    let policyAmount = this.choosePlanForm.controls[field].value;
    if (policyAmount === 0 || !policyAmount) {
      policyAmount = policyAmount + 10;
    } else {
      policyAmount++;
    }
    this.choosePlanForm.controls[field].setValue(policyAmount);
    console.log(
      'this.detailsTwoForm.controls[field].value ' +
        this.choosePlanForm.controls[field].value
    );
    this.checkForDisplay(policyAmount, field);
    this.isProceed = false;
  }

  checkForDisplay(val, field) {
    if (val === 0 || !val) {
      if (field === 'cancer') {
        this.cancerShiled = false;
      } else if (field === 'cardiac') {
        this.cardiacShield = false;
      } else if (field === 'livo') {
        this.livoShield = false;
      } else {
        this.neuroShiled = false;
      }
    } else {
      if (field === 'cancer') {
        this.cancerShiled = true;
      } else if (field === 'cardiac') {
        this.cardiacShield = true;
      } else if (field === 'livo') {
        this.livoShield = true;
      } else {
        this.neuroShiled = true;
      }
    }
  }
  changeAnnual(val: string) {
    this.annual = val;
    this.showMonthPremium = false;
    if (val === 'Annually') {
      this.totalAmount = '₹ 10,000';
      this.planYears = '45 Years';
    } else if (val === 'Monthly') {
      this.totalAmount = '₹ 833.33';
      this.planYears = '45 Years';
      this.showMonthPremium = true;
    } else {
      this.totalAmount = '₹ 5,00,000';
      this.planYears = '1 Year';
    }
  }
  calculatePrem() {
    this.formSubmitted = true;
    if (
      this.cancerShiled ||
      this.cardiacShield ||
      this.livoShield ||
      this.neuroShiled
    ) {
      this.isProceed = !this.isProceed;
    } else {
      setTimeout(() => {
        this.moveToError();
      }, 500);
    }
  }
  back() {
    this.router.navigate(['landing']);
  }
  navigate() {
    this.formSubmitted = true;
    if (
      this.cancerShiled ||
      this.cardiacShield ||
      this.livoShield ||
      this.neuroShiled
    ) {
      this.router.navigate(['benefits-discount']);
    } else {
      setTimeout(() => {
        this.moveToError();
      }, 500);
    }
  }
  termClicked(status) {
    if (status) {
      this.showTerm = false;
    } else {
      this.showTerm = true;
    }
  }

  validateNumber(evt) {
    if (evt.target.value.length <= 2) {
      var theEvent = evt || window.event;
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
      var regex = /^[0-9]\d*$/;
      if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
      }
    } else {
      return false;
    }
  }

  getInsurance(v) {
    this.insuranceCardSumAssured = v;
  }
  getPolicyCover(v) {
    this.insuranceCardPolicyCover = v;
  }
  onPremiumCard(v) {
    this.premiumCard = v;
  }

  moveToError() {
    var elt = $('.errorMsg');
    if (elt.length) {
      $('html, body').animate(
        {
          scrollTop: elt.first().offset().top - 90,
        },
        500
      );
    }
  }
}
