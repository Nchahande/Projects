import { ResumePageComponent } from './components/resume-page/resume-page.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LandingPageComponent } from './components/landing-page/landing-page.component';
import { ChoosePlanComponent } from './components/choose-plan/choose-plan.component';
import { BenefitsDiscountComponent } from './components/benefits-discount/benefits-discount.component';
import { PersonalDetailsComponent } from './components/personal-details/personal-details.component';
import { AdditionalDetailsComponent } from './components/additional-details/additional-details.component';
import { PolicyHealthComponent } from './components/policy-health/policy-health.component';
import { PersonalHealthComponent } from './components/personal-health/personal-health.component';
import { OtherDetailsComponent } from './components/other-details/other-details.component';
import { PlanUpdateComponent } from './components/plan-update/plan-update.component';
import { ResidentialDetailsComponent } from './components/residential-details/residential-details.component';
import { NomineeDetailsComponent } from './components/nominee-details/nominee-details.component';
import { PayoutDetailsComponent } from './components/payout-details/payout-details.component';
import { PaymentDetailsComponent } from './components/payment-details/payment-details.component';
import { ReviewDetailsComponent } from './components/review-details/review-details.component';
import { UploadDocumentsComponent } from './components/upload-documents/upload-documents.component';
import { SuccessComponent } from './components/success/success.component';
import { FailedComponent } from './components/failed/failed.component';
import{ AbortComponent} from './components/abort/abort.component';


const routes: Routes = [
  { path: '', redirectTo: '/landing', pathMatch: 'full' },
  { path: 'landing', component: LandingPageComponent, },
  { path: 'choose-plan', component: ChoosePlanComponent },
  { path: 'benefits-discount', component: BenefitsDiscountComponent },
  { path: 'personal-details', component: PersonalDetailsComponent },
  { path: 'additional-details', component: AdditionalDetailsComponent },
  { path: 'policy-health', component: PolicyHealthComponent },
  { path: 'personal-health', component: PersonalHealthComponent },
  { path: 'other-details', component: OtherDetailsComponent },
  { path: 'plan-update', component: PlanUpdateComponent },
  { path: 'residential-details', component: ResidentialDetailsComponent },
  { path: 'nominee-details', component: NomineeDetailsComponent },
  { path: 'payout-details', component: PayoutDetailsComponent },
  { path: 'review-details', component: ReviewDetailsComponent },
  { path: 'payment-details', component: PaymentDetailsComponent },
  { path: 'upload-documents', component: UploadDocumentsComponent },
  { path: 'success', component: SuccessComponent },
  { path: 'failed', component: FailedComponent },
  { path: 'abort', component: AbortComponent },
  { path: 'resume-page', component: ResumePageComponent },
  { path: '**', redirectTo: '/landing' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }

