import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeRoutingModule } from './home-routing.module';
import { FooterComponent } from '../../shared/footer/footer.component';
import { LandingPageComponent } from './components/landing-page/landing-page.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxIntlTelInputModule } from 'ngx-intl-tel-input';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HeaderComponent } from 'src/app/shared/header/header.component';
import { ReviewDetailsComponent } from './components/review-details/review-details.component';
import { PaymentDetailsComponent } from './components/payment-details/payment-details.component';
import { CarouselComponent } from './components/carousel/carousel.component';
import { ResumePageComponent } from './components/resume-page/resume-page.component';
import { ClickOutsideModule } from 'ng-click-outside';
import { ComboBoxComponent } from './components/combo-box/combo-box.component';
import { ChoosePlanComponent } from './components/choose-plan/choose-plan.component';
import { BenefitsDiscountComponent } from './components/benefits-discount/benefits-discount.component';
import { PersonalDetailsComponent } from './components/personal-details/personal-details.component';
import { AdditionalDetailsComponent } from './components/additional-details/additional-details.component';
import { PolicyHealthComponent } from './components/policy-health/policy-health.component';
import { PersonalHealthComponent } from './components/personal-health/personal-health.component';
import { OtherDetailsComponent } from './components/other-details/other-details.component';
import { PlanUpdateComponent } from './components/plan-update/plan-update.component';
import { ResidentialDetailsComponent } from './components/residential-details/residential-details.component';
import { NomineeDetailsComponent } from './components/nominee-details/nominee-details.component';
import { PayoutDetailsComponent } from './components/payout-details/payout-details.component';
import { UploadDocumentsComponent } from './components/upload-documents/upload-documents.component';
import { SuccessComponent } from './components/success/success.component';
import { FailedComponent } from './components/failed/failed.component';

import { CarouselModule } from 'ngx-owl-carousel-o';
import { AbortComponent } from './components/abort/abort.component';
@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    LandingPageComponent,
    ReviewDetailsComponent,
    PaymentDetailsComponent,
    CarouselComponent,
    ResumePageComponent,
    ComboBoxComponent,
    ChoosePlanComponent,
    BenefitsDiscountComponent,
    PersonalDetailsComponent,
    AdditionalDetailsComponent,
    PolicyHealthComponent,
    PersonalHealthComponent,
    OtherDetailsComponent,
    PlanUpdateComponent,
    ResidentialDetailsComponent,
    NomineeDetailsComponent,
    PayoutDetailsComponent,
    UploadDocumentsComponent,
    SuccessComponent,
    FailedComponent,
    AbortComponent,
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    ScrollingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    NgxIntlTelInputModule,
    BsDropdownModule.forRoot(),
    ClickOutsideModule,
    CarouselModule
  ]
})
export class HomeModule { }
