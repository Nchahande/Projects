import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export const mobileValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
    if (!control.parent || !control) {
        return null;
    }
    const mobile = control.parent.get('phoneNumber');

    if (!mobile) {
        return null;
    }

    if (mobile.value == '') {
        return null;
    }
    if (mobile.value.toString().length == 10)
        return null;
    return { hasCustomError: true };
};