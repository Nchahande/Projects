export class GlobalConstants {
    public static cancerShiled: boolean = false;
    public static cardiacShield: boolean = false;
    public static livoShield: boolean = false;
    public static neuroShiled: boolean = false;
      
    public static siteTitle: string = "This is example of ItSolutionStuff.com";
}